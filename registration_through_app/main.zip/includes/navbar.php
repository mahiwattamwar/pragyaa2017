<!-- Dropdown Structure -->
  <!-- <ul id="nav_drop" class="dropdown-content">
    <li><a href="#">Home</a></li>
    <li><a href="#">Submit</a></li>
    <li><a href="#">Notices</a></li>
    <li class="divider"></a></li>
    <li><a href="../pages/logout.php">LogOut</a></li>
  </ul> -->

  <nav>
    <div class="nav-wrapper white-text">
      <a href="#!" class="brand-logo white-text">Pragyaa 2017</a>
      <ul class="right hide-on-med-and-down">
      </ul>
    </div>
  </nav>